package bankPack;

public enum AccountType {
    SPARINGACCOUNT, NORMALACCOUNT
}
